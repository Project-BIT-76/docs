import tensorflow as tf
from tensorflow.keras.layers import Input, Dense, Conv1D, MaxPooling1D, Concatenate, TimeDistributed
from tensorflow.keras.models import Model

from peak_hour_frame.layers.transformer.causal_self_attention import CausalSelfAttention
from peak_hour_frame.layers.transformer.cross_attention import CrossAttention
from peak_hour_frame.layers.transformer.encoder_layer import EncoderLayer
from peak_hour_frame.layers.transformer.feed_forward import FeedForward


# Assuming EncoderLayerKAN, CausalSelfAttention, CrossAttention, FeedForwardKAN are defined elsewhere
# from custom_layers import EncoderLayerKAN, CausalSelfAttention, CrossAttention, FeedForwardKAN

class PredictionModel:
    def __init__(self, data_timesteps, data_features, holiday_timesteps, holiday_features):
        self.data_timesteps = data_timesteps
        self.data_features = data_features
        self.holiday_timesteps = holiday_timesteps
        self.holiday_features = holiday_features
        self.model = self._build_model()

    def _build_model(self):
        # Input layers
        input_data = Input(shape=(self.data_timesteps, self.data_features), name='input_data')
        input_holidays = Input(shape=(self.holiday_timesteps, self.holiday_features), name='input_holidays')

        # Normalize inputs
        norm_layer = tf.keras.layers.Normalization()(input_data)
        layer_holiday = tf.keras.layers.Normalization()(input_holidays)

        # Data Encoder Layers
        encoder_layer = TimeDistributed(Dense(units=64))(norm_layer)
        encoder_layer = EncoderLayer(d_model=64, num_heads=8, dff=64)(encoder_layer)

        # CNN Encoder Layers
        encoder_cnn_layer = Conv1D(filters=64, kernel_size=2, activation="relu")(norm_layer)
        encoder_cnn_layer = MaxPooling1D(pool_size=2)(encoder_cnn_layer)
        encoder_cnn_layer = Conv1D(filters=64, kernel_size=2, activation="relu")(encoder_cnn_layer)
        encoder_cnn_layer = MaxPooling1D(pool_size=2)(encoder_cnn_layer)
        encoder_cnn_layer = Conv1D(filters=64, kernel_size=2, activation="relu")(encoder_cnn_layer)
        encoder_cnn_layer = MaxPooling1D(pool_size=2)(encoder_cnn_layer)
        encoder_cnn_layer = TimeDistributed(Dense(units=64))(encoder_cnn_layer)
        encoder_cnn_layer = EncoderLayer(d_model=64, num_heads=8, dff=64)(encoder_cnn_layer)

        # Holiday Processing
        layer_holiday = TimeDistributed(Dense(units=64))(layer_holiday)
        layer_holiday = CausalSelfAttention(num_heads=8, key_dim=64)(layer_holiday)

        # Cross-Attention Layers
        layer_ca = CrossAttention(num_heads=8, key_dim=64)(layer_holiday, encoder_layer)
        layer_ca_cnn = CrossAttention(num_heads=8, key_dim=64)(layer_holiday, encoder_cnn_layer)

        # Combine Outputs
        layer_combined = Concatenate()([layer_ca, layer_ca_cnn])
        layer = FeedForward(128, 64)(layer_combined)

        # Output Layer
        out_class = TimeDistributed(Dense(25, activation='softmax', name='outputDense'), name='output')(layer)

        # Define Model
        model = Model(inputs=[input_data, input_holidays], outputs=out_class)
        return model

    def compile(self, optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy']):
        """Compile the model with the specified optimizer, loss, and metrics."""
        self.model.compile(optimizer=optimizer, loss=loss, metrics=metrics)

    def summary(self):
        """Print the model summary."""
        return self.model.summary()

    def fit(self, *args, **kwargs):
        """Train the model using the given data."""
        return self.model.fit(*args, **kwargs)

    def predict(self, *args, **kwargs):
        """Make predictions using the model."""
        return self.model.predict(*args, **kwargs)

# Example usage:
# model = PredictionModel(data_timesteps=336, data_features=5, holiday_timesteps=14, holiday_features=3)
# model.compile()
# model.summary()
# model.fit(x_train, y_train, epochs=10)
